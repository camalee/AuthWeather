//https://medium.com/better-programming/build-a-login-system-in-node-js-f1ba2abd19a

const express = require('express');
const app = express();
const port = process.env.PORT || 9999;
const expressejslayout = require('express-ejs-layouts')

// using mongoose
const mongoose = require("mongoose");
mongoose.Promise = global.Promise; // tell mongoos to use ES6 promises
//database connection
mongoose.connect("mongodb://localhost:27017/weatherdata", {useNewUrlParser: true})
.then(() => {
  console.log (" Mongo database connected")
})
.catch(err => {
  console.log ("No mongo database connection")
  console.log(err)
})

//use view engine to see ejs file
app.set('view engine', 'ejs');

//middleware
app.use(express.static('public'));
app.use(expressejslayout);
//bodyparser
app.use(express.urlencoded({ extended: false }))


//import route from weather.js
const weatherRoute = require('./routes/weather');

//routes
app.use('/weather', weatherRoute);
app.use('/users',require('./routes/users'));
app.use('/',require('./routes/weather'));

//models
require('./models/User');
require('./config/passport'); //must be below all models




//starting the server
app.listen(port, () => {
console.log(`This app is listening on http://localhost:${port}`)})





















