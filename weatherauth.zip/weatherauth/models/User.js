const mongoose = require('mongoose');
 
//building a database schema, defining the schema
//create userSchema to read and write data from a collection
const userSchema = new mongoose.Schema ({
    name: {
        type: String,
        required: true
    },
    email: {
        type: String,
        required: true
      },
      password: {
        type: String,
        required: true
      }
    });
    //compile model and pass collection name and our schema as the parameters
    const User = mongoose.model('User', userSchema);
     // export the User model
    module.exports = User;
   