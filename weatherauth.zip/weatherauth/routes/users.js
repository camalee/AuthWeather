//http://www.passportjs.org/docs/username-password/

const express = require('express');
const router = express.Router();
const passport = require('passport');
const bcrypt = require('bcryptjs');

// Load User model
const User = require('../models/User');

//Register page
router.get('/register', (req, res) => res.render('Register'));

//Login page
router.get('/login', (req, res) => res.render('Login'));

//login post route
router.post('/login', (req, res, next) => {
    passport.authenticate('local', {
      successRedirect: '/index',
      failureRedirect: '/users/login',
      failureFlash: true
      
    })(req, res, next);
  });
  
  //logout get route
  router.get('/logout', (req, res) => {
    req.logout();
    res.redirect('/users/login');
  });
     
//register post route
router.post('/register', async (req, res) => {
    try{
        const hashPwd = await bcrypt.hash(req,body.password,8)
        users.push({
            name: req.body.name,
            email: req.body.email,
            password: hashedpwd
        })
        res.render('/login')
    }
    catch{
        res.render('/register')

    }
    console.log(users)
    
    })



module.exports = router;