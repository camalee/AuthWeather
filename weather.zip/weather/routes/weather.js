//This holds the get post route for the weather app

const router = require('express').Router();

const fetch = require('node-fetch');

require('dotenv').config()

router.get('/', (req, res) => {
  res.render('index', {
    //set to null so first time users of app get a blank index file
    city: null,
    temp: null,
    descript: null,
    icon: null,
    
  });
});

router.post('/', async (req, res) => {
  const city = req.body.city;
  const url = `https://api.openweathermap.org/data/2.5/weather?q=${city}&units=metric&appid=${process.env.API_KEY}`; //change units to metric, made city a constant

  try {
    await fetch(url)
      .then(res => res.json())
      .then(data =>  {
          
         const city = data.name;
         const temp = Math.round(data.main.temp); //round the temperature so you eliminate decimals
         const icon = data.weather[0].icon;
         const descript = data.weather[0].description;

         
          res.render('index', {
            city,temp, descript, icon,  // same as above variable names
          });
        });
      
  } catch (err) {
    res.render('index', {
      city: 'Oh no! That city does not exist',
      temp: null,
      descript: null,
      icon: null,
      
    })
  }

})


module.exports = router;





