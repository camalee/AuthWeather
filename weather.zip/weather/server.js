const express = require('express');
const app = express();
const port = process.env.PORT || 5000;

//middleware
app.use(express.static('public'));
app.use(express.urlencoded({ extended: true }))

//import route from weather.js
const weatherRoute = require('./routes/weather');

//use view engine to see ejs file
app.set('view engine', 'ejs');

//middleware route for weatherroute
app.use('/', weatherRoute);



//starting the server
app.listen(port, () => {
console.log(`This app is listening on http://localhost:${port}`)})

























// const express = require('express')
// //const request = require('request')
// //var bodyParser = require('body-parser');
// //const path = require('path');
// var cors = require('cors');
// // import route from weather.js
// const weatherroute = require('./routes/weather');
// //create express app
// const app = express();

// // enabling CORS for all requests
// app.use(cors());

// // show style.css file in index.ejs file in express app
// app.use(express.static('public'));

// // Using middleware 
// app.use(express.urlencoded({ extended: true }));


// // use view engine to see ejs file/
// app.set('view engine', 'ejs');
// //middleware route for weatherroute
// app.use('/',weatherroute);


// //const city = ' Toronto, Canada'
// //const url = 'api.openweathermap.org/data/2.5/weather?q=${city}&appid=f44a003f192875b14bd6641887134224'
// const port = process.env.PORT || 9999



// // // Using bodyParser middleware to parse JSON bodies into JS objects
// // app.use(bodyParser.urlencoded({ extended: true }));
// // app.use(bodyParser.json());

// // // create get route request
// // app.get('/', function(req,res){
// //     request(url,function(err,response,body){
// // //weather JSON object
// //         weatherJSON = JSON.parse(body);
// //         console.log(weatherJSON);

// //         var weather = {
// //             city : city,
// //             temperature: Math.round(weatherJSON.main.temp), // round the temperature so you eliminate decimals
// //             description: weatherJSON.weather[0].description,
// //             icon: weatherJSON.weather[0].icon
// //         };
// //  // putting key,variable into object      
// //         const weatherdata = {key: weather};
// // // use res.render to load up an ejs view file 
// // // weather data passed through the template
// //         res.render('index', weatherdata);

// //     });
    
// // });
// // starting the server
// app.listen(port, () => {
//     console.log(`This app is listening on http://localhost:${port}`)
//   })
